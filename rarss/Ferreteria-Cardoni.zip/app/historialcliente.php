<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class historialcliente extends Model
{
    //
}
