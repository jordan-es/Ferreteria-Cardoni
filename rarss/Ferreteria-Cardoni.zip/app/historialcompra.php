<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class historialcompra extends Model
{
    //
}
