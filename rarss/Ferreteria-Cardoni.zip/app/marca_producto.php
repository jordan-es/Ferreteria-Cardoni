<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class marca_producto extends Model
{
    
}
